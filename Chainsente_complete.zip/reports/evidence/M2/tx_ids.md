# M2 placeholder TXIDs
- example: <INSERT_TXID_M2>