name: Feature request
about: Suggest an idea
title: "[FEATURE]"
---
**Describe the feature**
**Motivation**
