name: Bug report
about: Create a report to help us improve
title: "[BUG]"
labels: bug
---
**Describe the bug**
**Steps to reproduce**
**Expected behavior**
