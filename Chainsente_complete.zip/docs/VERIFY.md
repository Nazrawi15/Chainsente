# VERIFY - expanded

See top-level README. This file describes more detailed steps and expected outputs for reviewers.
