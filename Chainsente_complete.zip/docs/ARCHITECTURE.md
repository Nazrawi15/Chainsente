Detailed architecture: contracts on-chain leverage reference inputs. Off-chain agents compute liquidation and prepare txs.
