# Risk Register (summary)

- Price oracle accuracy: Mitigate with signed feeds, freshness checks.
- User shock on liquidation: Use partial liquidation and clear UX. Socialize UX in workshops.
- Talent bottleneck: pre-vet contractors, backups.
