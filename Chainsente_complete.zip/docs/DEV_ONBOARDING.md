# Dev Onboarding

- Install Node, Python, Aiken.
- Run aiken test in contracts/aiken.
- Run cli simulator for replay.
