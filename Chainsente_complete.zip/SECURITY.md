# Security Policy

Report vulnerabilities to security@chainsente.example or open an issue labeled 'security'.
Do not include sensitive data in issues.
